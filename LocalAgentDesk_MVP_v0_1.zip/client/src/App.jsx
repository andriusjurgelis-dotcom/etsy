import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Activity, AlertTriangle, Bot, CheckCircle2, Clipboard, Folder, Play, Plus, RefreshCw, Square, Terminal, XCircle, FileText, Image as ImageIcon } from 'lucide-react';

const API = 'http://localhost:3333';
const WS = 'ws://localhost:3333';

async function api(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

const statusClass = {
  Working: 'working',
  'Needs Approval': 'approval',
  Finished: 'finished',
  Error: 'error',
  Stopped: 'stopped'
};

function StatusDot({ status }) {
  return <span className={`status-dot ${statusClass[status] || 'stopped'}`} />;
}

function ProjectList({ projects, selectedId, setSelectedId, onNew }) {
  return <aside className="sidebar">
    <div className="brand">
      <div className="brand-icon"><Bot size={20} /></div>
      <div>
        <strong>Local Agent Desk</strong>
        <span>Project-first AI workspace</span>
      </div>
    </div>
    <button className="new-project" onClick={onNew}><Plus size={16}/> New Project</button>
    <div className="project-list">
      {projects.map((p) => (
        <button key={p.id} className={`project-item ${selectedId === p.id ? 'active' : ''} ${p.needsApproval ? 'needs-attention' : ''}`} onClick={() => setSelectedId(p.id)}>
          <StatusDot status={p.status} />
          <div className="project-copy">
            <strong>{p.name}</strong>
            <span>{p.status || 'Stopped'}</span>
          </div>
          {p.needsApproval && <AlertTriangle size={16} />}
        </button>
      ))}
    </div>
  </aside>
}

function NewProjectModal({ onClose, onCreated }) {
  const [form, setForm] = useState({ name: '', projectPath: '', launchCommand: 'ollama launch claude', createFolder: false, notes: '' });
  const [error, setError] = useState('');
  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const data = await api('/api/projects', { method: 'POST', body: JSON.stringify(form) });
      onCreated(data.project);
      onClose();
    } catch (err) {
      setError(err.message);
    }
  };
  return <div className="modal-backdrop">
    <form className="modal" onSubmit={submit}>
      <h2>Add Project</h2>
      <p>Attach an existing folder or create a new one. The app will add a local .agent-desk memory folder.</p>
      <label>Project name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Beauty Salon Business Hub" /></label>
      <label>Project folder path<input value={form.projectPath} onChange={(e) => setForm({ ...form, projectPath: e.target.value })} placeholder="/Users/andriusjurgelis/Documents/MyProject" /></label>
      <label>Launch command<input value={form.launchCommand} onChange={(e) => setForm({ ...form, launchCommand: e.target.value })} /></label>
      <label className="checkbox"><input type="checkbox" checked={form.createFolder} onChange={(e) => setForm({ ...form, createFolder: e.target.checked })} /> Create folder if missing</label>
      <label>Notes<textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional project notes" /></label>
      {error && <div className="error-box">{error}</div>}
      <div className="modal-actions"><button type="button" onClick={onClose}>Cancel</button><button type="submit" className="primary">Add Project</button></div>
    </form>
  </div>;
}

function ActivityFeed({ events, project }) {
  const items = events.filter((e) => e.projectId === project?.id).slice(-80);
  return <div className="feed">
    {items.length === 0 && <div className="empty-state"><Activity size={28}/><h3>No activity yet</h3><p>Start the agent or send a prompt. Raw terminal output stays hidden unless you open it.</p></div>}
    {items.map((e, idx) => <div className={`event ${e.level || 'info'}`} key={idx}>
      <span>{new Date(e.time || Date.now()).toLocaleTimeString()}</span>
      <p>{e.text || e.type}</p>
    </div>)}
  </div>
}

function ApprovalCard({ project, sendKey, rawOpen }) {
  if (!project?.needsApproval) return null;
  return <div className="approval-card">
    <div className="approval-title"><AlertTriangle size={18}/> Needs approval</div>
    <p>The hidden agent terminal is waiting for your response.</p>
    <div className="approval-actions">
      <button className="approve" onClick={() => sendKey('approve')}>Approve</button>
      <button className="deny" onClick={() => sendKey('deny')}>Deny</button>
      <button onClick={rawOpen}>Open Raw Console</button>
    </div>
    <div className="mini-keys">
      <button onClick={() => sendKey('up')}>↑</button>
      <button onClick={() => sendKey('down')}>↓</button>
      <button onClick={() => sendKey('enter')}>Enter</button>
      <button onClick={() => sendKey('escape')}>Esc</button>
    </div>
  </div>
}

function RightPanel({ project, reloadProject, pushEvent }) {
  const [report, setReport] = useState(null);
  const [memory, setMemory] = useState('');
  const [raw, setRaw] = useState('');
  const [showRaw, setShowRaw] = useState(false);

  useEffect(() => {
    if (!project) return;
    api(`/api/projects/${project.id}/report`).then(setReport).catch(() => setReport(null));
    api(`/api/projects/${project.id}/memory`).then((d) => setMemory(d.content)).catch(() => setMemory(''));
  }, [project?.id, project?.latestReport?.mtimeMs]);

  const action = async (name) => {
    if (!project) return;
    await api(`/api/projects/${project.id}/${name}`, { method: 'POST' });
    pushEvent(project.id, `Command sent: ${name}`);
    reloadProject();
  };
  const sendKey = async (key) => {
    await api(`/api/projects/${project.id}/key`, { method: 'POST', body: JSON.stringify({ key }) });
    pushEvent(project.id, `Key sent: ${key}`);
    reloadProject();
  };
  const openRaw = async () => {
    const d = await api(`/api/projects/${project.id}/raw`);
    setRaw(d.output || '');
    setShowRaw(true);
  };
  const copyReport = async () => {
    if (report?.content) await navigator.clipboard.writeText(report.content);
  };

  if (!project) return <aside className="right-panel"><p>Select a project.</p></aside>;

  return <aside className="right-panel">
    <div className="panel-card status-card">
      <div className="panel-title"><StatusDot status={project.status}/><strong>{project.status || 'Stopped'}</strong></div>
      <p>{project.path}</p>
      <div className="button-grid">
        <button onClick={() => action('start')}><Play size={15}/> Start</button>
        <button onClick={() => action('stop')}><Square size={15}/> Stop</button>
        <button onClick={() => action('restart')}><RefreshCw size={15}/> Restart</button>
        <button onClick={openRaw}><Terminal size={15}/> Raw Console</button>
      </div>
    </div>

    <ApprovalCard project={project} sendKey={sendKey} rawOpen={openRaw} />

    <div className="panel-card">
      <div className="panel-title"><FileText size={16}/><strong>Latest MD Report</strong></div>
      {report ? <><p>{report.file.name}</p><pre className="report-preview">{report.content.slice(0, 900)}</pre><button onClick={copyReport}><Clipboard size={15}/> Copy Report</button></> : <p>No report yet.</p>}
    </div>

    <div className="panel-card">
      <div className="panel-title"><ImageIcon size={16}/><strong>Latest Screenshot</strong></div>
      {project.latestScreenshot ? <p>{project.latestScreenshot.name}</p> : <p>No screenshot yet.</p>}
    </div>

    <div className="panel-card memory-card">
      <div className="panel-title"><Folder size={16}/><strong>Project Memory</strong></div>
      <textarea value={memory} onChange={(e) => setMemory(e.target.value)} />
      <button onClick={async () => { await api(`/api/projects/${project.id}/memory`, { method: 'PUT', body: JSON.stringify({ content: memory }) }); pushEvent(project.id, 'Project memory saved.'); }}>Save Memory</button>
    </div>

    {showRaw && <div className="raw-modal">
      <div className="raw-box"><button className="close" onClick={() => setShowRaw(false)}><XCircle size={18}/></button><h3>Raw Console</h3><pre>{raw || 'No raw output captured yet.'}</pre></div>
    </div>}
  </aside>;
}

function PromptBox({ project, pushEvent }) {
  const [text, setText] = useState('');
  const send = async () => {
    if (!text.trim() || !project) return;
    await api(`/api/projects/${project.id}/send`, { method: 'POST', body: JSON.stringify({ text }) });
    pushEvent(project.id, `You: ${text.slice(0, 160)}`);
    setText('');
  };
  return <div className="prompt-box">
    <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={project ? `Send prompt to ${project.name}` : 'Select project first'} />
    <button className="primary" onClick={send} disabled={!project}>Send</button>
  </div>;
}

export default function App() {
  const [projects, setProjects] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [events, setEvents] = useState([]);
  const [modal, setModal] = useState(false);
  const selected = useMemo(() => projects.find((p) => p.id === selectedId) || projects[0], [projects, selectedId]);

  const pushEvent = (projectId, text, level = 'info') => setEvents((e) => [...e, { projectId, text, level, time: Date.now() }]);
  const load = async () => {
    const data = await api('/api/projects');
    setProjects(data.projects);
    if (!selectedId && data.projects[0]) setSelectedId(data.projects[0].id);
  };
  useEffect(() => { load(); }, []);
  useEffect(() => {
    const ws = new WebSocket(WS);
    ws.onmessage = (msg) => {
      const payload = JSON.parse(msg.data);
      if (payload.type === 'project-status') {
        setProjects((ps) => ps.map((p) => p.id === payload.projectId ? { ...p, ...payload.patch } : p));
      }
      if (payload.type === 'activity') pushEvent(payload.projectId, payload.text, payload.level);
      if (payload.type === 'approval') pushEvent(payload.projectId, 'Agent is asking for approval.', 'warn');
      if (payload.type === 'report-added') { pushEvent(payload.projectId, `New report: ${payload.file.name}`, 'success'); load(); }
      if (payload.type === 'screenshot-added') { pushEvent(payload.projectId, `New screenshot: ${payload.file.name}`, 'info'); load(); }
    };
    return () => ws.close();
  }, []);

  return <div className="app-shell">
    <ProjectList projects={projects} selectedId={selected?.id} setSelectedId={setSelectedId} onNew={() => setModal(true)} />
    <main className="main">
      <header className="main-header">
        <div><h1>{selected?.name || 'No project selected'}</h1><p>{selected?.launchCommand || 'Add a project to begin.'}</p></div>
        {selected && <div className="header-status"><StatusDot status={selected.status}/>{selected.status}</div>}
      </header>
      <ActivityFeed events={events} project={selected} />
      <PromptBox project={selected} pushEvent={pushEvent} />
    </main>
    <RightPanel project={selected} reloadProject={load} pushEvent={pushEvent} />
    {modal && <NewProjectModal onClose={() => setModal(false)} onCreated={(p) => { setProjects((x) => [p, ...x]); setSelectedId(p.id); }} />}
  </div>;
}
