# Local Agent Desk

A local browser dashboard for running coding agents in hidden terminal sessions while you work from a clean project/chat interface.

## What it does

- Manage many projects from one place
- Start an agent in the correct project folder automatically
- Use hidden pseudo terminals instead of visible terminal windows
- Send prompts through a ChatGPT-style project workspace
- Detect approval requests and show Approve / Deny / Custom Reply buttons
- Keep per-project memory in `.agent-desk/`
- Detect latest Markdown reports and screenshots
- Keep raw console hidden unless needed

## First run

```bash
cd LocalAgentDesk
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

The API server runs on:

```text
http://localhost:3333
```

## Default agent command

The first version is configured for your current workflow:

```bash
ollama launch claude
```

You can change this per project when adding a project.

## Project memory

Each attached project gets:

```text
.agent-desk/
├── project-memory.md
├── current-task.md
├── decisions.md
├── prompts/
├── reports/
├── screenshots/
├── logs/
└── sessions/
```

When an agent starts, Local Agent Desk sends a startup instruction telling it to read project memory and write reports back to `.agent-desk/reports/`.

## Important limitation

This is an MVP. Approval detection is pattern based. If the agent shows a complicated interactive menu, use **Open Raw Console** or the mini key buttons.

## Safety

The app does not auto approve requests. You must click Approve yourself.
