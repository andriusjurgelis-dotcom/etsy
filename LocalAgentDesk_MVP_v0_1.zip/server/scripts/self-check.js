const fs = require('fs');
const path = require('path');
const required = [
  'server/index.js',
  'server/agentManager.js',
  'server/storage.js',
  'client/src/App.jsx',
  'client/src/styles.css',
  'README.md',
  'package.json'
];
let ok = true;
for (const file of required) {
  const full = path.resolve(__dirname, '..', '..', file);
  if (!fs.existsSync(full)) {
    console.error(`Missing: ${file}`);
    ok = false;
  } else {
    console.log(`OK: ${file}`);
  }
}
process.exit(ok ? 0 : 1);
