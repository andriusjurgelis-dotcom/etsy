const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const chokidar = require('chokidar');
const { WebSocketServer } = require('ws');
const crypto = require('crypto');
const {
  appRoot,
  ensureDir,
  loadState,
  saveState,
  ensureProjectWorkspace,
  getAgentDeskPath,
  listFilesRecursive,
  readTextSafe,
  os
} = require('./storage');
const { AgentManager } = require('./agentManager');

const PORT = process.env.PORT || 3333;
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
let state = loadState();
const watchers = new Map();

app.use(express.json({ limit: '5mb' }));

function broadcast(payload) {
  const msg = JSON.stringify(payload);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(msg);
  }
}

function projectPublic(project) {
  const reports = getReports(project.id);
  const screenshots = getScreenshots(project.id);
  return { ...project, latestReport: reports[0] || null, latestScreenshot: screenshots[0] || null };
}

function getProject(id) {
  return state.projects.find((p) => p.id === id);
}

const agents = new AgentManager({ broadcast, getProject });

function watchProject(project) {
  if (watchers.has(project.id)) return;
  const desk = getAgentDeskPath(project.path);
  ensureProjectWorkspace(project);
  const watcher = chokidar.watch([path.join(desk, 'reports'), path.join(desk, 'screenshots')], {
    ignoreInitial: true,
    awaitWriteFinish: { stabilityThreshold: 400, pollInterval: 100 }
  });
  watcher.on('add', (file) => {
    const ext = path.extname(file).toLowerCase();
    if (ext === '.md') broadcast({ type: 'report-added', projectId: project.id, file: fileInfo(file) });
    if (['.png', '.jpg', '.jpeg', '.webp'].includes(ext)) broadcast({ type: 'screenshot-added', projectId: project.id, file: fileInfo(file) });
  });
  watchers.set(project.id, watcher);
}

function fileInfo(file) {
  const stat = fs.statSync(file);
  return { path: file, name: path.basename(file), mtimeMs: stat.mtimeMs, size: stat.size };
}

state.projects.forEach((p) => {
  try { watchProject(p); } catch {}
});

function getReports(id) {
  const project = getProject(id);
  if (!project) return [];
  return listFilesRecursive(path.join(getAgentDeskPath(project.path), 'reports'), (file) => file.toLowerCase().endsWith('.md'));
}

function getScreenshots(id) {
  const project = getProject(id);
  if (!project) return [];
  return listFilesRecursive(path.join(getAgentDeskPath(project.path), 'screenshots'), (file) => /\.(png|jpg|jpeg|webp)$/i.test(file));
}

app.get('/api/projects', (req, res) => {
  res.json({ projects: state.projects.map(projectPublic) });
});

app.post('/api/projects', (req, res) => {
  const { name, projectPath, launchCommand, notes, createFolder } = req.body;
  if (!name || !projectPath) return res.status(400).json({ error: 'name and projectPath are required' });
  const fullPath = projectPath.replace(/^~/, os.homedir());
  if (createFolder) ensureDir(fullPath);
  if (!fs.existsSync(fullPath)) return res.status(400).json({ error: 'Project folder does not exist. Enable createFolder or choose existing folder.' });

  const project = {
    id: crypto.randomUUID().slice(0, 10),
    name,
    path: fullPath,
    launchCommand: launchCommand || 'ollama launch claude',
    notes: notes || '',
    status: 'Stopped',
    needsApproval: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  ensureProjectWorkspace(project);
  state.projects.unshift(project);
  saveState(state);
  watchProject(project);
  res.json({ project: projectPublic(project) });
});

app.patch('/api/projects/:id', (req, res) => {
  const project = getProject(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  Object.assign(project, req.body, { updatedAt: new Date().toISOString() });
  saveState(state);
  res.json({ project: projectPublic(project) });
});

app.delete('/api/projects/:id', (req, res) => {
  const id = req.params.id;
  agents.stop(id);
  const watcher = watchers.get(id);
  if (watcher) watcher.close();
  watchers.delete(id);
  state.projects = state.projects.filter((p) => p.id !== id);
  saveState(state);
  res.json({ ok: true });
});

app.post('/api/projects/:id/start', (req, res) => {
  try {
    agents.start(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/projects/:id/stop', (req, res) => {
  agents.stop(req.params.id);
  res.json({ ok: true });
});

app.post('/api/projects/:id/restart', (req, res) => {
  try { agents.restart(req.params.id); res.json({ ok: true }); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

app.post('/api/projects/:id/send', (req, res) => {
  try { agents.send(req.params.id, req.body.text || ''); res.json({ ok: true }); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

app.post('/api/projects/:id/key', (req, res) => {
  try { agents.key(req.params.id, req.body.key); res.json({ ok: true }); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

app.get('/api/projects/:id/reports', (req, res) => res.json({ reports: getReports(req.params.id) }));
app.get('/api/projects/:id/screenshots', (req, res) => res.json({ screenshots: getScreenshots(req.params.id) }));

app.get('/api/projects/:id/report', (req, res) => {
  const reports = getReports(req.params.id);
  if (!reports[0]) return res.status(404).json({ error: 'No report found' });
  res.json({ file: reports[0], content: readTextSafe(reports[0].path) });
});

app.get('/api/projects/:id/memory', (req, res) => {
  const project = getProject(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const file = path.join(getAgentDeskPath(project.path), 'project-memory.md');
  res.json({ content: readTextSafe(file), file });
});

app.put('/api/projects/:id/memory', (req, res) => {
  const project = getProject(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const file = path.join(getAgentDeskPath(project.path), 'project-memory.md');
  fs.writeFileSync(file, req.body.content || '');
  res.json({ ok: true });
});

app.get('/api/projects/:id/raw', (req, res) => res.json({ output: agents.getRaw(req.params.id) }));

wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'hello', projects: state.projects.map(projectPublic) }));
});

if (process.env.NODE_ENV === 'production') {
  const clientDist = path.join(appRoot, 'client', 'dist');
  app.use(express.static(clientDist));
  app.get('*', (req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}

server.listen(PORT, () => {
  console.log(`Local Agent Desk API running on http://localhost:${PORT}`);
});
