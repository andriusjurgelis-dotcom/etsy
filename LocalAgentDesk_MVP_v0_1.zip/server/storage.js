const fs = require('fs');
const path = require('path');
const os = require('os');

const appRoot = path.resolve(__dirname, '..');
const dataDir = path.join(appRoot, 'data');
const projectsFile = path.join(dataDir, 'projects.json');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function safeJsonRead(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, value) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}

function loadState() {
  ensureDir(dataDir);
  const state = safeJsonRead(projectsFile, { projects: [] });
  if (!Array.isArray(state.projects)) state.projects = [];
  return state;
}

function saveState(state) {
  writeJson(projectsFile, state);
}

function getAgentDeskPath(projectPath) {
  return path.join(projectPath, '.agent-desk');
}

function ensureProjectWorkspace(project) {
  const base = getAgentDeskPath(project.path);
  const dirs = ['prompts', 'reports', 'screenshots', 'logs', 'sessions'];
  ensureDir(base);
  dirs.forEach((d) => ensureDir(path.join(base, d)));

  const memory = path.join(base, 'project-memory.md');
  const task = path.join(base, 'current-task.md');
  const decisions = path.join(base, 'decisions.md');

  if (!fs.existsSync(memory)) {
    fs.writeFileSync(memory, `# ${project.name}\n\n## Project Purpose\n\nDescribe this project here.\n\n## Tech Stack\n\nUnknown yet.\n\n## Important Rules\n\n- Keep this project separate from other projects.\n- Write final reports to .agent-desk/reports/.\n- Do not make destructive changes without user approval.\n\n## Current Status\n\nNew project attached to Local Agent Desk.\n`);
  }
  if (!fs.existsSync(task)) fs.writeFileSync(task, `# Current Task\n\nNo active task yet.\n`);
  if (!fs.existsSync(decisions)) fs.writeFileSync(decisions, `# Decisions\n\nNo decisions recorded yet.\n`);

  return base;
}

function listFilesRecursive(dir, predicate, max = 50) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const file of fs.readdirSync(dir)) {
    const full = path.join(dir, file);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) continue;
    if (!predicate || predicate(full)) {
      out.push({ path: full, name: file, mtimeMs: stat.mtimeMs, size: stat.size });
    }
  }
  return out.sort((a, b) => b.mtimeMs - a.mtimeMs).slice(0, max);
}

function readTextSafe(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch {
    return '';
  }
}

module.exports = {
  appRoot,
  dataDir,
  projectsFile,
  ensureDir,
  loadState,
  saveState,
  ensureProjectWorkspace,
  getAgentDeskPath,
  listFilesRecursive,
  readTextSafe,
  os
};
