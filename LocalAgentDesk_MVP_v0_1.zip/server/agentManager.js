const fs = require('fs');
const path = require('path');
const pty = require('node-pty');
const { ensureDir, getAgentDeskPath, readTextSafe } = require('./storage');

const approvalPatterns = [
  /do you want to allow/i,
  /approve/i,
  /permission/i,
  /continue\?/i,
  /proceed\?/i,
  /\by\/n\b/i,
  /yes\/no/i,
  /allow this/i,
  /press enter/i
];

class AgentManager {
  constructor({ broadcast, getProject }) {
    this.sessions = new Map();
    this.broadcast = broadcast;
    this.getProject = getProject;
  }

  status(projectId, patch) {
    this.broadcast({ type: 'project-status', projectId, patch });
  }

  makeStartupPrompt(project) {
    const desk = getAgentDeskPath(project.path);
    const memory = readTextSafe(path.join(desk, 'project-memory.md'));
    const task = readTextSafe(path.join(desk, 'current-task.md'));
    const latestReport = this.latestReportText(project);
    return `\nYou are now working inside this project folder:\n${project.path}\n\nBefore making changes, use this project context.\n\nPROJECT MEMORY:\n${memory}\n\nCURRENT TASK:\n${task}\n\nLATEST REPORT, IF ANY:\n${latestReport || 'No previous report found.'}\n\nRules for this session:\n1. Work only inside this project folder unless I explicitly say otherwise.\n2. Do not ask routine permission for normal file edits inside this project.\n3. Stop and ask before destructive actions, deleting major assets, paid services, billing/signing credentials, or actions outside this project folder.\n4. After completing work, write a clear Markdown report to:\n${path.join(desk, 'reports')}\n5. Report must include files changed, functions changed, commands/tests run, results, remaining risks, and next recommended step.\n\nWait for my next instruction if no task has been provided.\n`;
  }

  latestReportText(project) {
    const reportsDir = path.join(getAgentDeskPath(project.path), 'reports');
    try {
      if (!fs.existsSync(reportsDir)) return '';
      const files = fs.readdirSync(reportsDir)
        .filter((name) => name.toLowerCase().endsWith('.md'))
        .map((name) => {
          const full = path.join(reportsDir, name);
          return { full, mtime: fs.statSync(full).mtimeMs };
        })
        .sort((a, b) => b.mtime - a.mtime);
      if (!files[0]) return '';
      const text = fs.readFileSync(files[0].full, 'utf8');
      return text.slice(0, 6000);
    } catch {
      return '';
    }
  }

  start(projectId) {
    const project = this.getProject(projectId);
    if (!project) throw new Error('Project not found');
    if (this.sessions.has(projectId)) return this.sessions.get(projectId);

    ensureDir(path.join(getAgentDeskPath(project.path), 'logs'));
    const logFile = path.join(getAgentDeskPath(project.path), 'logs', `session-${Date.now()}.log`);
    const command = project.launchCommand || 'ollama launch claude';
    const shell = process.env.SHELL || '/bin/zsh';

    const term = pty.spawn(shell, ['-lc', command], {
      name: 'xterm-256color',
      cols: 120,
      rows: 35,
      cwd: project.path,
      env: process.env
    });

    const session = {
      projectId,
      term,
      logFile,
      outputBuffer: '',
      startedAt: new Date().toISOString(),
      needsApproval: false
    };
    this.sessions.set(projectId, session);
    this.status(projectId, { status: 'Working', startedAt: session.startedAt, needsApproval: false });
    this.broadcast({ type: 'activity', projectId, level: 'info', text: `Started agent with: ${command}` });

    const startupPrompt = this.makeStartupPrompt(project);
    const startupPath = path.join(getAgentDeskPath(project.path), 'prompts', `startup-${Date.now()}.md`);
    fs.writeFileSync(startupPath, startupPrompt);

    setTimeout(() => {
      if (this.sessions.has(projectId)) {
        term.write(startupPrompt.replace(/\n/g, '\r') + '\r');
        this.broadcast({ type: 'activity', projectId, level: 'info', text: 'Startup project memory sent to agent.' });
      }
    }, 1800);

    term.onData((data) => {
      fs.appendFileSync(logFile, data);
      session.outputBuffer = (session.outputBuffer + data).slice(-12000);
      this.broadcast({ type: 'terminal-data', projectId, data });

      if (!session.needsApproval && approvalPatterns.some((p) => p.test(session.outputBuffer))) {
        session.needsApproval = true;
        this.status(projectId, { status: 'Needs Approval', needsApproval: true });
        this.broadcast({ type: 'approval', projectId, text: session.outputBuffer.slice(-2000) });
      }
    });

    term.onExit(({ exitCode }) => {
      this.sessions.delete(projectId);
      this.status(projectId, { status: exitCode === 0 ? 'Finished' : 'Stopped', needsApproval: false, exitCode });
      this.broadcast({ type: 'activity', projectId, level: exitCode === 0 ? 'success' : 'warn', text: `Agent exited with code ${exitCode}` });
    });

    return session;
  }

  stop(projectId) {
    const session = this.sessions.get(projectId);
    if (!session) return;
    session.term.kill();
    this.sessions.delete(projectId);
    this.status(projectId, { status: 'Stopped', needsApproval: false });
  }

  restart(projectId) {
    this.stop(projectId);
    setTimeout(() => this.start(projectId), 300);
  }

  send(projectId, text) {
    const session = this.sessions.get(projectId);
    if (!session) throw new Error('Agent is not running');
    const project = this.getProject(projectId);
    const promptPath = path.join(getAgentDeskPath(project.path), 'prompts', `prompt-${Date.now()}.md`);
    fs.writeFileSync(promptPath, text);
    session.needsApproval = false;
    this.status(projectId, { status: 'Working', needsApproval: false });
    session.term.write(text.replace(/\n/g, '\r') + '\r');
    this.broadcast({ type: 'activity', projectId, level: 'info', text: 'Prompt sent.' });
  }

  key(projectId, key) {
    const session = this.sessions.get(projectId);
    if (!session) throw new Error('Agent is not running');
    const map = {
      enter: '\r',
      escape: '\x1b',
      up: '\x1b[A',
      down: '\x1b[B',
      left: '\x1b[D',
      right: '\x1b[C',
      approve: 'y\r',
      deny: 'n\r'
    };
    session.needsApproval = false;
    this.status(projectId, { status: 'Working', needsApproval: false });
    session.term.write(map[key] || key);
    this.broadcast({ type: 'activity', projectId, level: 'info', text: `Sent key: ${key}` });
  }

  getRaw(projectId) {
    const session = this.sessions.get(projectId);
    return session ? session.outputBuffer : '';
  }
}

module.exports = { AgentManager };
